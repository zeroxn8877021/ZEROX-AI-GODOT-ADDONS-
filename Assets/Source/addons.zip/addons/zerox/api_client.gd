@tool
extends Node

const API_URL = "https://api.groq.com/openai/v1/chat/completions"
var api_key = ""

signal request_completed(response_text)
signal request_failed(error_message)

func setup(key: String):
	api_key = key

func send_prompt(prompt: String, system_message: String):
	var http_request = HTTPRequest.new()
	add_child(http_request)
	http_request.request_completed.connect(_on_request_completed.bind(http_request))

	var headers = [
		"Content-Type: application/json",
		"Authorization: Bearer " + api_key
	]

	var body = JSON.stringify({
		"model": "llama-3.3-70b-versatile",
		"messages": [
			{"role": "system", "content": system_message},
			{"role": "user", "content": prompt}
		],
		"temperature": 0.5
	})

	var error = http_request.request(API_URL, headers, HTTPClient.METHOD_POST, body)
	if error != OK:
		request_failed.emit("Failed to initiate request.")
		http_request.queue_free()

func _on_request_completed(result, response_code, headers, body, http_request):
	var body_str = body.get_string_from_utf8()
	var response = JSON.parse_string(body_str)
	http_request.queue_free()

	if response_code == 200 and response.has("choices"):
		var content = response["choices"][0]["message"]["content"]
		request_completed.emit(content)
	else:
		var error_msg = "Error (" + str(response_code) + ")"
		if response and response.has("error"):
			error_msg += ": " + response["error"]["message"]
		request_failed.emit(error_msg)
