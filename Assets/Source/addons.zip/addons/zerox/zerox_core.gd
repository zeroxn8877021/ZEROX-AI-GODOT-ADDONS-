@tool
extends Node

# Zerox Professional Core v1.2
# Author: Paras Sharma

const LOGIC_PATH = "res://zerox_logic.gd"

func process_ai_response(content: String):
	var actions = []
	
	# 1. Logic Generation
	var script_content = extract_block(content, "gdscript")
	if script_content != "":
		script_content = heal_logic(script_content)
		save_logic(script_content)
		actions.append("Logic: Synchronized.")
	
	# 2. Scene Architecture
	var scene_json = extract_block(content, "json")
	if scene_json != "":
		var data = JSON.parse_string(scene_json)
		if data and data.has("nodes"):
			var result = build_scene_v1_2(data)
			actions.append(result)
	
	if actions.size() == 0:
		return "Analysis: Incomplete data blocks."
	return " | ".join(actions)

func extract_block(text: String, lang: String) -> String:
	var pattern = "```" + lang
	var start = text.find(pattern)
	if start == -1: return ""
	start += pattern.length()
	var end = text.find("```", start)
	if end == -1: return ""
	return text.substr(start, end - start).strip_edges()

func heal_logic(code: String) -> String:
	var lines = code.split("\n")
	var new_lines = []
	var is_character_body = "extends CharacterBody" in code or "extends KinematicBody" in code
	
	for line in lines:
		var l = line
		# Fix annotations
		if l.strip_edges().begins_with("export"): l = l.replace("export", "@export")
		if l.strip_edges().begins_with("onready"): l = l.replace("onready", "@onready")
		# Fix Godot 4 specific API
		l = l.replace("move_and_slide(velocity)", "move_and_slide()")
		l = l.replace(".instance()", ".instantiate()")
		# Remove duplicate velocity in CharacterBody
		if is_character_body and "var velocity" in l: continue
		new_lines.append(l)
	
	return "\n".join(new_lines)

func save_logic(code: String):
	var file = FileAccess.open(LOGIC_PATH, FileAccess.WRITE)
	if file:
		file.store_string(code)
		file.close()
		EditorInterface.get_resource_filesystem().scan()

func build_scene_v1_2(data: Dictionary) -> String:
	var root = EditorInterface.get_edited_scene_root()
	if not root:
		return "Error: No active scene. Create a Root Node first."

	var nodes_map = {}
	for n in data["nodes"]:
		var type = n.get("type", "Node3D")
		if not ClassDB.class_exists(type): continue
			
		var node = ClassDB.instantiate(type)
		node.name = n.get("name", type)
		root.add_child(node)
		node.owner = root
		nodes_map[node.name] = node
		
		if n.has("properties"):
			apply_props(node, n["properties"])
		
		if n.get("attach_logic", false):
			var script = load(LOGIC_PATH)
			if script: node.set_script(script)

	if data.has("connections"):
		for conn in data["connections"]:
			var from = nodes_map.get(conn["from"])
			var to = nodes_map.get(conn["to"])
			if from and to:
				from.connect(conn["signal"], Callable(to, conn["method"]))

	return "Built " + str(data["nodes"].size()) + " nodes."

func apply_props(node: Node, props: Dictionary):
	for key in props:
		var val = props[key]
		if val is Array:
			if val.size() == 3: val = Vector3(val[0], val[1], val[2])
			elif val.size() == 2: val = Vector2(val[0], val[1])
		
		if node is MeshInstance3D and key == "mesh":
			node.mesh = create_mesh_v1_2(val)
			continue
		node.set(key, val)

func create_mesh_v1_2(type: String):
	match type:
		"BoxMesh": return BoxMesh.new()
		"SphereMesh": return SphereMesh.new()
		"PlaneMesh": return PlaneMesh.new()
	return null
