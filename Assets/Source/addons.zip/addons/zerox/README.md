# ZEROX: Professional AI Engine for Godot 4

ZEROX is a high-performance automation tool designed for professional game development in Godot Engine 4. It provides seamless scene construction, asset configuration, and logic generation.

## Author
**Paras Sharma**

## Core Features
- **Automated Scene Architecture**: Intelligent root initialization and node hierarchy construction.
- **Asset Configuration**: Automated mesh generation, material application, and property mapping.
- **Signal & Logic Binding**: Automatic connection of signals and attachment of generated GDScript logic.
- **Professional Syntax Sanitizer**: Ensures Godot 4 compatibility for all generated scripts.

## Installation
1. Place the `zerox` folder in your project's `addons/` directory.
2. Enable the plugin in **Project Settings > Plugins**.
3. Access the **ZEROX** dock in the editor.

## Usage
Ensure an active scene is open in the editor. Enter a descriptive prompt and execute. ZEROX will build the requested elements directly into your workspace.
