@tool
extends Control

@onready var api_key_field = $VBox/KeyContainer/KeyInput
@onready var prompt_field = $VBox/PromptEdit
@onready var log_view = $VBox/Output
@onready var status_label = $VBox/Status

var api_client
var core

func _ready():
	api_client = preload("res://addons/zerox/api_client.gd").new()
	add_child(api_client)
	api_client.request_completed.connect(_on_ai_success)
	api_client.request_failed.connect(_on_ai_failure)
	
	core = preload("res://addons/zerox/zerox_core.gd").new()
	add_child(core)
	
	# Pre-fill user's key
	api_key_field.text = "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"

func _on_generate_pressed():
	var key = api_key_field.text
	var prompt = prompt_field.text
	
	if key.is_empty() or prompt.is_empty():
		status_label.text = "Status: Key or Prompt missing"
		return
	
	status_label.text = "Status: Thinking..."
	api_client.setup(key)
	
	var system_msg = """
	You are Zerox v1.2, a professional Godot 4 AI Engine.
	
	Goal: Build functional scenes and logic.
	
	Rules:
	1. Use ```gdscript for code. No duplicate 'velocity' variables.
	2. Use ```json for scene structure.
	3. Set "attach_logic": true to attach the generated script.
	4. Use "mesh": "BoxMesh" etc for MeshInstance3D.
	
	Example JSON:
	{
		"nodes": [
			{"type": "MeshInstance3D", "name": "Cube", "properties": {"mesh": "BoxMesh"}, "attach_logic": true}
		]
	}
	"""
	api_client.send_prompt(prompt, system_msg)

func _on_ai_success(content):
	log_view.text = content
	var result = core.process_ai_response(content)
	status_label.text = "Status: " + result
	if "Error" in result:
		status_label.modulate = Color.RED
	else:
		status_label.modulate = Color.GREEN

func _on_ai_failure(error):
	status_label.text = "Status: " + error
	log_view.text = "Detailed Error: " + error
