@tool
extends EditorPlugin

const ZEROX_DOCK = preload("res://addons/zerox/zerox_dock.tscn")
var dock_instance

func _enter_tree():
	dock_instance = ZEROX_DOCK.instantiate()
	add_control_to_dock(DOCK_SLOT_RIGHT_BL, dock_instance)
	print("Zerox: AI System Initialized")

func _exit_tree():
	if dock_instance:
		remove_control_from_docks(dock_instance)
		dock_instance.queue_free()
	print("Zerox: AI System Deactivated")
